fin=load('partb0g.txt');
t_B0=fin(:,1);
f_B0=fin(:,2);
s_B0=fin(:,3);
fin=load('partb100g.txt');
t_B100=fin(:,1);
s_B100=fin(:,3);
fin=load('partb200g.txt');
t_B200=fin(:,1);
s_B200=fin(:,3);
fin=load('partb300g.txt');
t_B300=fin(:,1);
s_B300=fin(:,3);
fin=load('partb400g.txt');
t_B400=fin(:,1);
s_B400=fin(:,3);
fin=load('partb500g.txt');
t_B500=fin(:,1);
s_B500=fin(:,3);
t_B=[t_B0;t_B100;t_B200;t_B300;t_B400;t_B500];
s_B=[s_B0;s_B100;s_B200;s_B300;s_B400;s_B500];
fin=load('partc.txt');
t_C=fin(:,1);
s_C=fin(:,3);
v_C=fin(:,4);
accC=fin(:,5);
fin=load('partgdamping.txt');
t_g=fin(:,1);
s_g=fin(:,3);
v_g=fin(:,4);
accG=fin(:,5);
mSpr=0.0289;
massB=[0*ones(300,1);0.1*ones(300,1);0.2*ones(300,1);0.3*ones(300,1);0.4*ones(300,1);0.5*ones(300,1)];
masses = [0,.100, .200, .300, .400, .500];
mPlate=0.0102;
mTray=0.1002;
%{
for m=masses
    fin=readtable(join(['partb',int2str(m),'g.txt'])).Position;
    t_D=[t_D,fin(:,1)];
    s_D=[s_D,fin(:,2)];
end
%}
fprintf("theoratical force measured at 0g should be: %.4f;\n measured is: %.4f\n", ...
    (0.05+mSpr)*9.8,mean(f_B0));
ws=[];
restPos=mean(s_B0);
for i=1:300:length(massB)
    stdErr=std(s_B(i:300+i-1)-restPos)/sqrt(300);
    ws=[ws;1/stdErr^2*ones(300,1)];
end
res=linlsqfit1_Wang(massB,s_B-restPos,ws);
A=res(1);B=res(2);uncA=res(3);uncB=res(4);

%%
% part C
figure;

plot(massB,A+B.*massB,'-g','LineWidth',3);
hold on;
plot(massB,s_B-restPos,':r','LineWidth',3);
title('x vs mass');
xlabel('mass/kg'); ylabel('x/m');
legend('modeled line in A+Bx form','actual data');
hold off;
k=9.80665/abs(B);
fprintf("k is: %.4f\n",k);
uncK=9.80665/B^2*uncB;

Ks1=(massB(length(s_B0)+1:end)+0.05+mSpr).*9.80665./(s_B(length(s_B0)+1:end)-mean(s_B0));
T=2*pi*sqrt(0.55/k);
T1=2*pi*sqrt((0.55+mSpr/3)/k);
m=0.5;
uncPtB=(2*pi*sqrt(m)/k^(3/2))/2*(uncK);
fprintf("from part B, without spring mass, T is:%.4f\n",T);
fprintf("with spring mass, T is: %.4f\n\n",T1);
%%
% part D
figure;
subplot(2,2,1);
plot(t_C,s_C-mean(s_B500));
title('500 g mass: x vs t');
xlabel('t/s');ylabel('x/m');
subplot(2,2,2);
plot(t_C,v_C);
title('500 g mass: v vs t');
xlabel('t/s');ylabel('v/ m/s');
subplot(2,2,3);
plot(t_C,accC);
title('500 g mass: a vs t');xlabel('t\s');ylabel('a/ m/s^2')

%%
% part E-F
uncT=pi*sqrt((0.55+mSpr)/k^3)*uncK;
fprintf('uncertainty of T is: %.4d\n',uncT);
% zero crossing doesn't work as well as counting sign turns so I'm using
% sign turns here
crsAcc=[];
flag=true;
for i=1:length(accC)-1
  if flag&&accC(i)*accC(i+1)<0
      crsAcc=[crsAcc,t_C(i)];
      flag=false;
  else
      flag=true;
  end
end


zeroCrsAcc=[];
for i=1:2:length(crsAcc)-2
    zeroCrsAcc=[zeroCrsAcc,crsAcc(i+2)-crsAcc(i)];
end
crsX=[];
flag=true;
for i=1:length(s_C)-1
    if flag&&(s_C(i)-mean(s_B500))*(s_C(i+1)-mean(s_B500))<0
        crsX=[crsX,t_C(i)];
        flag=false;
    else
        flag=true;
    end
end
crsV=[];
flag=true;
for i=1:length(v_C)-1
   if flag&&v_C(i)*v_C(i+1)<0
       crsV=[crsV,t_C(i)];
       flag=false;
   else
       flag=true;
   end
end


zeroCrsX=[];zeroCrsV=[];
for i=1:2:length(crsX)-1
    zeroCrsX=[zeroCrsX,crsX(i+2)-crsX(i)];
end
for i=1:2:length(crsV)-2
    zeroCrsV=[zeroCrsV,crsV(i+2)-crsV(i)];
end

fprintf("from crossing zero, T is:\n %.4f for acceleration," + ...
    " %.4f for position, %.4f for velocity\n",mean(zeroCrsAcc),mean(zeroCrsX),mean(zeroCrsV));


%%
% part G
figure;
plot(t_C,v_C,'r');
hold on;
plot(t_C,accC,'b');
plot(t_C,s_C-mean(s_B500),'g');
title('x,v,a vs t');
legend('v','a','x');
lens=min(length(crsAcc),min(length(crsV),length(crsX)));
dPhi=2*pi*abs(crsAcc(1:lens)-crsX(1:lens))/T;
dPhi1=2*pi*abs(crsV(1:lens)-crsX(1:lens))/T;
dPhi2=2*pi*abs(crsAcc(1:lens)-crsV(1:lens))/T;
disp(mean(dPhi)/pi);
disp(mean(dPhi1)/pi);
disp(mean(dPhi2)/pi);

% air resistance present
equiPos=1.138;

figure;
plot(v_C,s_C-mean(s_B500));
title('v vs x');
xlabel('x/m');ylabel('v/ m/s');

peaks=[];
peakPos=[];
for i=2:length(s_g)-1
    if abs(s_g(i))>abs(s_g(i-1))&&abs(s_g(i))>abs(s_g(i+1))
        peaks=[peaks,t_g(i)];
        peakPos=[peakPos,s_g(i)];
    end
end
ws=1./(std(peakPos-equiPos)^2/length(peakPos)./(peakPos-equiPos));
figure;

res=linlsqfit1_Wang(peaks,log(abs(peakPos-equiPos)),ws);
gA=res(1);gB=res(2);uncgA=res(3);uncgB=res(4);

plot(peaks,gB*peaks+gA,'-r','LineWidth',3);

hold on;
plot(peaks,log(abs(peakPos-equiPos)),':g','LineWidth',3);
title('ln peak pos vs time');
ylabel('ln peak');xlabel('time/s');

legend('model','actual');
disp(gA);disp(gB);

% omega damping
disp(sqrt((2*pi/T)-B^2));
%%
% part H
figure;
plot(s_g-equiPos,v_g);
title('v vs x');ylabel('v/ m/s');xlabel('x/m');



