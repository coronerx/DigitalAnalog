function result=linlsqfit1_Wang(x,y,w)

    D=sum(w)*sum(w.*x.^2)-sum(w.*x)^2;
    A=(sum(x.^2.*w)*sum(w.*y)-sum(x.*w)*sum(x.*w.*y))/D;
    B=(sum(w)*sum(w.*x.*y)-sum(w.*x)*sum(w.*y))/D;
    uncA=sqrt(sum(w.*x.^2)/D);
    uncB=sqrt(sum(w)/D);
    result=[A,B,uncA,uncB];
end